aclocal && autoheader && automake --add-missing --gnu --copy && autoconf
