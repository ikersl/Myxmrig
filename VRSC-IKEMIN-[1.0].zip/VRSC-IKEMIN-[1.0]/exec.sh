./ccminer -a verus -o stratum+tcp://ussw.vipor.net:5040 -u RUN9vZTyvXWPbKKv1SKPk1jLVgxv6zfzYG -p Rpi3 -t 4
